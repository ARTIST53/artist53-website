# ARTIST53 v1.0

Production-ready static website for ARTIST53.

## Deploy on Cloudflare Pages

Framework preset: None  
Build command: leave blank  
Output directory: `/` or `.`

Make sure `index.html` stays in the root of the repository.
